# pokedexapp

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

825180058/jason irvin can